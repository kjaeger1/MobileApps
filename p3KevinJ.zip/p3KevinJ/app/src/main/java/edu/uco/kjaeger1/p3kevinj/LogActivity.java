package edu.uco.kjaeger1.p3kevinj;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

public class LogActivity extends Activity {
    ArrayList<String> gameHistory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

        // Obtain game history from TicTacToeActivity
        gameHistory = (ArrayList<String>) getIntent().getSerializableExtra("ArrayList");

        initializeTable();
    }

    private void initializeTable() {
        TableLayout table = (TableLayout) findViewById(R.id.table_main);

        // Column 1
        TableRow tableRow1 = new TableRow(this);
        TextView textView1 = new TextView(this);
        textView1.setText("   #   ");
        textView1.setTextColor(Color.BLACK);
        textView1.setTextSize(28);
        tableRow1.addView(textView1);

        // Column 2
        TextView textView2 = new TextView(this);
        textView2.setText(" Winner ");
        textView2.setTextColor(Color.BLACK);
        textView2.setTextSize(28);
        tableRow1.addView(textView2);
        table.addView(tableRow1);

        // Adds the rows
        for (int i = 0; i < gameHistory.size(); i++) {
            int gameNumber = i+1;

            TableRow tableRow = new TableRow(this);

            TextView tv1 = new TextView(this);
            tv1.setText(String.valueOf(gameNumber));
            tv1.setTextColor(Color.BLACK);
            tv1.setTextSize(28);
            tv1.setGravity(Gravity.CENTER);
            tableRow.addView(tv1);

            TextView tv2 = new TextView(this);
            tv2.setText(gameHistory.get(i));
            tv2.setTextColor(Color.BLACK);
            tv2.setTextSize(28);
            tv2.setGravity(Gravity.CENTER);
            tableRow.addView(tv2);
            table.addView(tableRow);
        }
    }
}
