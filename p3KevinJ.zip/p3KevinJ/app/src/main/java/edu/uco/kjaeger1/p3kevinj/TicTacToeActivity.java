package edu.uco.kjaeger1.p3kevinj;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

/*
 * This is the main activity for this application and creates a tic tac toe game.
 * When the user clicks on the Log Button, the LogActivity is launched and displays
 * the game history.
 */

public class TicTacToeActivity extends Activity {

    private TextView textDisplay;
    private Button button1, button2, button3, button4, button5,
                   button6, button7, button8, button9, logButton,
                   newGameButton;
    private ArrayList<Button> gameSquares;
    private String currentPlayer;
    private String nextPlayer;
    private int turnCount = 0;

    private ArrayList<String> gameHistory= new ArrayList<>();  // Stores the results of each game
                                                               // to send to Log Activity

    private TicTacToeListener listener = new TicTacToeListener(); // Listens for Button Presses

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tictactoe);
        getButtonReferencesFromLayout();
        getTextViewReferenceFromLayout();
        initializeTextView();
    }

    private class TicTacToeListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            // Determines whether to mark gameSquare with "X" or "O". O plays first.
            currentPlayer = determineCurrentPlayer(turnCount);
            nextPlayer = determineNextPlayer(turnCount);

            // If it is a gameSquare button mark the square and check for a winner
            // If it is the new game button then start a new game
            // If it is the log game button display the log
            performButtonAction(view);

                // If the button pressed is one of the game buttons then check for a winner
                if (gameSquares.contains(view))

                    // Checks for winner after every turn and disables buttons if game is over
                    if (playerWins()) {
                        textDisplay.setText("Game Over: Winner is " + currentPlayer + "!!!");
                        disableButtons();
                        gameHistory.add(currentPlayer);
                    }
                    // If all gameSquares are checked then game is over
                    else if (turnCount == gameSquares.size()) {
                        textDisplay.setText("Game Over: TIE - No Winner!!!");
                        gameHistory.add("draw");
                    }
                    // Displays next player's turn if there is not a winner and game is not a draw
                    else {
                        textDisplay.setText(nextPlayer + "'s Turn!");
                    }
        }
    }

    private String determineCurrentPlayer(int playerTurnCount) {
        String currentPlayer = "O";
        if (playerTurnCount%2 == 1) { currentPlayer = "X"; }
        return currentPlayer;
    }

    private String determineNextPlayer(int playerTurnCount) {
        String nextPlayer = "X";
        if (playerTurnCount%2 == 1) { nextPlayer = "O"; }
        return nextPlayer;
    }

    private void disableButtons() {
        for (Button b: gameSquares) { b.setEnabled(false); }
    }

    // Determines which button is pressed and performs appropriate action
    public void performButtonAction(View view) {

        // top left button
        if (view == gameSquares.get(0)) {
            turnCount++;
            gameSquares.get(0).setText(currentPlayer);
            gameSquares.get(0).setEnabled(false);

        }
        // top middle button
        else if (view == gameSquares.get(1)) {
            turnCount++;
            gameSquares.get(1).setText(currentPlayer);
            gameSquares.get(1).setEnabled(false);

        }
        // top right button
        else if (view == gameSquares.get(2)) {
            turnCount++;
            gameSquares.get(2).setText(currentPlayer);
            gameSquares.get(2).setEnabled(false);

        }
        // middle left button
        else if (view == gameSquares.get(3)) {
            turnCount++;
            gameSquares.get(3).setText(currentPlayer);
            gameSquares.get(3).setEnabled(false);

        }
        // middle middle button
        else if (view == gameSquares.get(4)) {
            turnCount++;
            gameSquares.get(4).setText(currentPlayer);
            gameSquares.get(4).setEnabled(false);

        }
        // middle right button
        else if (view == gameSquares.get(5)) {
            turnCount++;
            gameSquares.get(5).setText(currentPlayer);
            gameSquares.get(5).setEnabled(false);

        }
        // lower left button
        else if (view == gameSquares.get(6)) {
            turnCount++;
            gameSquares.get(6).setText(currentPlayer);
            gameSquares.get(6).setEnabled(false);

        }
        // lower middle button
        else if (view == gameSquares.get(7)) {
            turnCount++;
            gameSquares.get(7).setText(currentPlayer);
            gameSquares.get(7).setEnabled(false);

        }
        // lower right button
        else if (view == gameSquares.get(8)) {
            turnCount++;
            gameSquares.get(8).setText(currentPlayer);
            gameSquares.get(8).setEnabled(false);

        }
        else if (view == newGameButton) {
            createNewGame();
        }
        else if (view == logButton) {
            startLogActivity();
        }
    }

    private boolean playerWins() {
        // row one
        if (gameSquares.get(0).getText().equals(gameSquares.get(1).getText()) &&
                gameSquares.get(1).getText().equals(gameSquares.get(2).getText()) &&
                !gameSquares.get(0).getText().equals("")) {
            return true;
            // row two
        }
        else if (gameSquares.get(3).getText().equals(gameSquares.get(4).getText()) &&
                gameSquares.get(4).getText().equals(gameSquares.get(5).getText()) &&
                !gameSquares.get(3).getText().equals("")) {
            return true;
            // row three
        }
        else if (gameSquares.get(6).getText().equals(gameSquares.get(7).getText()) &&
                gameSquares.get(7).getText().equals(gameSquares.get(8).getText()) &&
                !gameSquares.get(6).getText().equals("")) {
            return true;
        }
        // column one
        else if (gameSquares.get(0).getText().equals(gameSquares.get(3).getText()) &&
                gameSquares.get(3).getText().equals(gameSquares.get(6).getText()) &&
                !gameSquares.get(0).getText().equals("")) {
            return true;
        }
        // column two
        else if (gameSquares.get(1).getText().equals(gameSquares.get(4).getText()) &&
                gameSquares.get(4).getText().equals(gameSquares.get(7).getText()) &&
                !gameSquares.get(1).getText().equals("")) {
            return true;
        }
        // column three
        else if (gameSquares.get(2).getText().equals(gameSquares.get(5).getText()) &&
                gameSquares.get(5).getText().equals(gameSquares.get(8).getText()) &&
                !gameSquares.get(2).getText().equals("")) {
            return true;
        }
        // diagonal one
        else if (gameSquares.get(0).getText().equals(gameSquares.get(4).getText()) &&
                gameSquares.get(4).getText().equals(gameSquares.get(8).getText()) &&
                !gameSquares.get(0).getText().equals("")) {
            return true;
        }
        // diagonal two
        else if (gameSquares.get(2).getText().equals(gameSquares.get(4).getText()) &&
                gameSquares.get(4).getText().equals(gameSquares.get(6).getText()) &&
                !gameSquares.get(2).getText().equals("")) {
            return true;
        }
        else {
            return false;
        }
    }

    public void createNewGame() {
        turnCount = 0;
        resetAllButtons();
        initializeTextView();
    }

    public void resetAllButtons() {
        for (Button b: gameSquares) {
            b.setText("");
            b.setEnabled(true);
        }
    }

    // Starts LogActivity and sends the gameHistory for display
    public void startLogActivity() {
        Intent intent = new Intent(TicTacToeActivity.this, LogActivity.class);
        intent.putExtra("ArrayList", gameHistory);
        startActivity(intent);
    }

    // Creates a reference to each button, attaches the listener to it, and
    // stores buttons into gamesquares ArrayList.
    private void getButtonReferencesFromLayout() {
        gameSquares = new ArrayList<>();

        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(listener);
        gameSquares.add(button1);

        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(listener);
        gameSquares.add(button2);

        button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(listener);
        gameSquares.add(button3);

        button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(listener);
        gameSquares.add(button4);

        button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(listener);
        gameSquares.add(button5);

        button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(listener);
        gameSquares.add(button6);

        button7 = (Button) findViewById(R.id.button7);
        button7.setOnClickListener(listener);
        gameSquares.add(button7);

        button8 = (Button) findViewById(R.id.button8);
        button8.setOnClickListener(listener);
        gameSquares.add(button8);

        button9 = (Button) findViewById(R.id.button9);
        button9.setOnClickListener(listener);
        gameSquares.add(button9);

        logButton = (Button) findViewById(R.id.log_button);
        logButton.setOnClickListener(listener);

        newGameButton = (Button) findViewById(R.id.new_game_button);
        newGameButton.setOnClickListener(listener);
    }

    private void getTextViewReferenceFromLayout() {
        textDisplay = (TextView) findViewById(R.id.text_display);
    }

    private void initializeTextView() {
        textDisplay.setText("Play Tic-Tac-Toe: O's Turn!");
    }
}
