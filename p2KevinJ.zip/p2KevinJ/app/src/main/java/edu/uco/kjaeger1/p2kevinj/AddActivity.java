package edu.uco.kjaeger1.p2kevinj;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/* Kevin Jaeger
 * Mobile Applications
 * p2 Due Sunday September 11th, 2016
 */

public class AddActivity extends Activity {
    public final static String NUMBER_1_ADD = "edu.uco.kjaeger1.NUMBER_1_ADD";
    public final static String NUMBER_2_ADD = "edu.uco.kjaeger1.NUMBER_2_ADD";
    public final static String RESULT_SUM = "edu.uco.kjaeger1.RESULT_SUM";
    private static final String TAG = "MYAPP";
    private double number1;
    private double number2;
    private double result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // set TextViews to display the two numbers received from ComputeActivity
        number1 = getIntent().getDoubleExtra(NUMBER_1_ADD, 0);
        number2 = getIntent().getDoubleExtra(NUMBER_2_ADD, 0);

        TextView num1 = (TextView) findViewById(R.id.num1input_add);
        num1.setText(Double.toString(number1));

        TextView num2 = (TextView) findViewById(R.id.num2input_add);
        num2.setText(Double.toString(number2));

        //Display result on clicking the "compute to add" button
        final TextView resultView = (TextView) findViewById(R.id.resultOutput_add);
        Button computeToAddButton = (Button) findViewById(R.id.addButton_add);
        computeToAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result = number1 + number2;
                resultView.setText(Double.toString(result));

                // return the sum to the Parent activity when user clicks back button
                setAdditionActivityResult();
                Log.v(TAG, String.valueOf(result));
            }
        });
    }
    // Sends back the sum of the two numbers to the parent ComputeActivity
    public void setAdditionActivityResult() {
        Intent data = new Intent();
        data.putExtra(RESULT_SUM, result);
        setResult(RESULT_OK, data);
    }

}

