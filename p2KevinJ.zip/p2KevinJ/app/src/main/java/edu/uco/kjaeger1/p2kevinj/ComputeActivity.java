package edu.uco.kjaeger1.p2kevinj;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/* Kevin Jaeger
 * Mobile Applications
 * p2 Due Sunday September 11th, 2016
 */

public class ComputeActivity extends Activity {
    public static final int REQUEST_CODE_ADDITION = 0;
    public static final int REQUEST_CODE_MULTIPLICATION = 1;
    private double number1;
    private double number2;
    private EditText num1input, num2input;
    private TextView resultOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compute);

        num1input = (EditText) findViewById(R.id.num1input);
        num2input = (EditText) findViewById(R.id.num2input);
        resultOutput = (TextView) findViewById(R.id.resultOutput);

        // Configure Add Button to send numbers to AddActivity
        Button addButton = (Button) findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ComputeActivity.this, AddActivity.class);
                number1 = Double.parseDouble(num1input.getText().toString());
                number2 = Double.parseDouble(num2input.getText().toString());
                intent.putExtra(AddActivity.NUMBER_1_ADD, number1);
                intent.putExtra(AddActivity.NUMBER_2_ADD, number2);
                startActivityForResult(intent, REQUEST_CODE_ADDITION);
            }
        });

        // Configure Multiply Button to send two numbers to MultiplyActivity
        Button multiplyButton = (Button) findViewById(R.id.multiplyButton);
        multiplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ComputeActivity.this, MultiplyActivity.class);
                number1 = Double.parseDouble(num1input.getText().toString());
                number2 = Double.parseDouble(num2input.getText().toString());
                intent.putExtra(MultiplyActivity.NUMBER_1_MULTIPLY, number1);
                intent.putExtra(MultiplyActivity.NUMBER_2_MULTIPLY, number2);
                startActivityForResult(intent, REQUEST_CODE_MULTIPLICATION);
            }
        });
    }

    // Receive the result from the children Activities and display in ResultOutput TextView
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        double result;
        if (data == null) {
            return;
        } else if (requestCode == REQUEST_CODE_ADDITION) {
            result = data.getDoubleExtra(AddActivity.RESULT_SUM, 0);
            resultOutput.setText(Double.toString(result));

        } else if (requestCode == REQUEST_CODE_MULTIPLICATION) {
            result = data.getDoubleExtra(MultiplyActivity.RESULT_MULTIPLICATION, 0);
            resultOutput.setText(Double.toString(result));
        }
    }
}
