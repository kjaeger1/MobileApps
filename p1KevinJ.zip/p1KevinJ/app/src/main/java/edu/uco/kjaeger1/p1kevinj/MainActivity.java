package edu.uco.kjaeger1.p1kevinj;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView textDisplay;
    Button nameButton, degreeButton, clearButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create instances of layout elements
        textDisplay = (TextView) findViewById(R.id.textDisplay);
        nameButton = (Button) findViewById(R.id.nameButton);
        degreeButton = (Button) findViewById(R.id.degreeButton);
        clearButton = (Button) findViewById(R.id.clearButton);

        // Change text on textDisplay when buttons are clicked
        nameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textDisplay.setText("Kevin Jaeger");
            }
        });
        degreeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textDisplay.setText("Computer Science and Applied Math");
            }
        });
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textDisplay.setText("");
            }
        });
    }
}
