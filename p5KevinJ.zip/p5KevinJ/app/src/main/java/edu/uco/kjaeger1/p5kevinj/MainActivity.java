package edu.uco.kjaeger1.p5kevinj;

import android.app.Activity;
import android.app.DialogFragment;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements DepartmentDialogFragment.PickDepartmentListener{

    private String websiteSelected = "http://www.google.com";

    // Notification ID to allow for future updates
    private static final int MY_NOTIFICATION_ID = 1;

    // Notification Action Elements
    private Intent notificationIntent;
    private PendingIntent mContentIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Start MyContacts Activity when My Contacts button is pressed
        Button myContactsButton = (Button) findViewById(R.id.my_contact_button);
        myContactsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MyContacts.class);
                startActivity(intent);
            }
        });

        // Launch a dialog fragment when the Departments button is pressed
        Button departmentInfoButton = (Button) findViewById(R.id.department_info_button);
        departmentInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DepartmentDialogFragment d = new DepartmentDialogFragment();
                d.show(getFragmentManager(), "departments");
            }
        });
    }

    // When a user chooses a department from the dialog menu, a notification will be sent and
    // if the notification is clicked on, it will launch an intent to visit the department website.
    @Override
    public void onPickDepartmentClick(int departmentIndex, DialogFragment dialog) {
        // Set the website to be visited based on department selected
        websiteSelected = getResources().getStringArray(R.array.dept_website_array)[departmentIndex];

        // Create intent for notification to launch browser and visit website
        notificationIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(websiteSelected));
        mContentIntent = PendingIntent.getActivity(this, 0,
                notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Define the Notification's expanded message and Intent:
        Notification.Builder notificationBuilder = new Notification.Builder(
                getApplicationContext())
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setAutoCancel(true)
                .setContentTitle("Department")
                .setContentText(
                        "Click to visit Department website!")
                .setContentIntent(mContentIntent);

        // Pass the Notification to the NotificationManager:
        NotificationManager mNotificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(MY_NOTIFICATION_ID,
                notificationBuilder.build());

    }
}
