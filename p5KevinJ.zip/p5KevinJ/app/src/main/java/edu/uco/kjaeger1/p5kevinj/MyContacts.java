package edu.uco.kjaeger1.p5kevinj;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;

import edu.uco.kjaeger1.p5kevinj.NamesFragment.ListSelectionListener;
/*
 * MyContacts hosts two fragments NamesFragment(a listview) and DetailsFragment(displays the
 * contact information when a name is clicked. It also creates the list of contacts that will
 * be used, and sorts that list.
 */
public class MyContacts extends Activity implements
        ListSelectionListener {

    public static ArrayList<String> lastNameArrayList = new ArrayList<>();
    public static ArrayList<Contact> contacts = new ArrayList<>();
    private DetailsFragment detailsFragment;

    private static final String TAG = "MyContactsActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createContacts();
        createLastNameArrayList();

        setContentView(R.layout.activity_my_contacts);

        detailsFragment = (DetailsFragment) getFragmentManager()
                .findFragmentById(R.id.details);
    }

    // Returns a list of only last names for the NamesFragment
    private void createLastNameArrayList() {
        for (Contact c: contacts) {
            lastNameArrayList.add(c.getLastName());
        }
    }

    // Displays the user details when a list element is selected
    @Override
    public void onListSelection(int index) {
        if (detailsFragment.getShownIndex() != index) {
            detailsFragment.showDetailsAtIndex(index);
        }
    }

    // Create an ArrayList of 20 contacts with info stored in String Resources
    public void createContacts() {
        String[] lastNames = getResources().getStringArray(R.array.contact_last_names);
        String[] firstNames = getResources().getStringArray(R.array.contact_first_names);
        String[] phoneNumber = getResources().getStringArray(R.array.contact_phone_number);
        String[] emailAddress = getResources().getStringArray(R.array.contact_email_address);

        for (int i = 0; i < lastNames.length; i++) {
            Contact c = new Contact(lastNames[i], firstNames[i], phoneNumber[i], emailAddress[i]);
            contacts.add(c);
        }
        Collections.sort(contacts);  // sort based on last name
        Log.v(TAG, "Contacts created and sorted successfully");

    }
}
