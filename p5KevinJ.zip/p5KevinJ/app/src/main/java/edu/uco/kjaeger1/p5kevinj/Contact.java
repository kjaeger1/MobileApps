package edu.uco.kjaeger1.p5kevinj;

/**
 * Created by kevinjaeger on 9/25/16.
 * This class will hold information for a person's last name,
 * first name, phone number, and email address.
 */

public class Contact implements Comparable<Contact> {

    private String lastName;
    private String firstName;
    private String phoneNumber;
    private String emailAddress;

    public Contact(String lastName, String firstName, String phoneNumber, String emailAddress){
        this.setLastName(lastName);
        this.setFirstName(firstName);
        this.setPhoneNumber(phoneNumber);
        this.setEmailAddress(emailAddress);
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    @Override
    public int compareTo(Contact contact) {
        return getLastName().compareTo(contact.getLastName());
    }
}
