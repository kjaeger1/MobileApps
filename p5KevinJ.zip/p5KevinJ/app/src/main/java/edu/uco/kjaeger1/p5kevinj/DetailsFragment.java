package edu.uco.kjaeger1.p5kevinj;


import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/*
 * The DetailsFragment class creates a fragment to
 * display a Contact's details on the right side of
 * the page when the last name is press on the left
 * side of the page. When a user's email address
 * is selected an intent will launch an email application
 */

public class DetailsFragment extends Fragment {

    private TextView nameView = null;
    private TextView phoneView = null;
    private TextView emailView = null;

    private int currentIndex = -1; // determines which contact's info to display
    private int contactListLength;

    private static final String TAG = "DetailsFragment";

    public DetailsFragment() {
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        contactListLength = MyContacts.contacts.size();

        createViewReferences();

        // Launches email application when email textView is pressed
        emailView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/rfc822");
                i.putExtra(Intent.EXTRA_EMAIL  , new String[]{emailView.getText().toString()});
                i.putExtra(Intent.EXTRA_SUBJECT, "Announcement from Mobile Apps Class");
                i.putExtra(Intent.EXTRA_TEXT   , "Would you like a million dollars?\n" +
                        "Please send me your bank account number and\n" +
                        "I will send you the million dollars very soon.\n" +
                        "Regards");
                try {
                    startActivity(Intent.createChooser(i, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    //Toast.makeText(, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void createViewReferences() {
        nameView = (TextView) getActivity().findViewById(R.id.nameView);
        phoneView = (TextView) getActivity().findViewById(R.id.phoneView);
        emailView = (TextView) getActivity().findViewById(R.id.emailView);
    }

    // Sets the fragment's view based on the name pressed in the listview on
    // the left side of the screen
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_details, container, false);
    }

    public int getShownIndex() {
        return currentIndex;
    }

    // Configure details view here when name is clicked on
    public void showDetailsAtIndex(int newIndex) {
        if (newIndex < 0 || newIndex >= contactListLength)
            return;
        currentIndex = newIndex;

        nameView.setText(MyContacts.contacts.get(currentIndex).getFirstName() +
        " " + MyContacts.contacts.get(currentIndex).getLastName());

        phoneView.setText(MyContacts.contacts.get(currentIndex).getPhoneNumber());

        emailView.setText(MyContacts.contacts.get(currentIndex).getEmailAddress());

    }
}
