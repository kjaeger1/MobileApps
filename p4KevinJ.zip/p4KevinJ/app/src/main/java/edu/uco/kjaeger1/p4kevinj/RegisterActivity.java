package edu.uco.kjaeger1.p4kevinj;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class RegisterActivity extends Activity {

    public final static String FULL_NAME = "edu.uco.kjaeger1.FULL_NAME";
    public final static String PASSWORD = "edu.uco.kjaeger1.PASSWORD";
    public final static String DATE_OF_BIRTH = "edu.uco.kjaeger1.DATE_OF_BIRTH";
    public final static String GENDER = "edu.uco.kjaeger1.GENDER";
    public final static String CLASSIFICATION = "edu.uco.kjaeger1.CLASSIFICATION";
    public final static String SKILLS = "edu.uco.kjaeger1.SKILLS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        TextView fullNameTextView = (TextView) findViewById(R.id.full_name_registered_textview);
        TextView passwordTextView = (TextView) findViewById(R.id.password_registered_textview);
        TextView dateOfBirthTextView = (TextView) findViewById(R.id.date_of_birth_registered_textview);
        TextView genderTextView = (TextView) findViewById(R.id.gender_registered_textview);
        TextView classificationTextView = (TextView) findViewById(R.id.classification_registered_textview);
        TextView skillsTextView = (TextView) findViewById(R.id.skills_registered_textview);

        String fullName = getIntent().getStringExtra(FULL_NAME);
        fullNameTextView.setText("Full Name: " + fullName);

        String password = getIntent().getStringExtra(PASSWORD);
        passwordTextView.setText("Password: " + password);

        String dateOfBirth = getIntent().getStringExtra(DATE_OF_BIRTH);
        dateOfBirthTextView.setText("Birth Date: " + dateOfBirth);

        String gender = getIntent().getStringExtra(GENDER);
        genderTextView.setText("Gender: " + gender);

        String classification = getIntent().getStringExtra(CLASSIFICATION);
        classificationTextView.setText("Class: " + classification);

        ArrayList<String> skills = new ArrayList<>();
        skills = getIntent().getStringArrayListExtra(SKILLS);
        StringBuilder skillsString = new StringBuilder();
        for (String s : skills) {
            skillsString.append(s + " ");
        }
        skillsTextView.setText("Skills: " + skillsString);


    }
}
