package edu.uco.kjaeger1.p4kevinj;

/**
 * Created by kevinjaeger on 9/25/16.
 */

public class Department {

    private String name;
    private String phoneNumber;
    private String website;

    public Department(String name, String phoneNumber, String website) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.website = website;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getWebsite() {
        return website;
    }
}
