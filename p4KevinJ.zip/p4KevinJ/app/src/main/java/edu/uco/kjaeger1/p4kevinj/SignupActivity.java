package edu.uco.kjaeger1.p4kevinj;

import android.app.Activity;
import android.app.DialogFragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.util.ArrayList;

public class SignupActivity extends Activity {

    private String fullName;
    private String password;
    private String gender;
    private RadioGroup genderRadioGroup;
    private RadioButton maleRadioButton, femaleRadioButton;
    private String dateOfBirth;
    private Button dateOfBirthButton;
    private ArrayList<String> skills = new ArrayList<>();
    private CheckBox androidCheckbox, javaCheckbox, cPlusCheckbox, swiftCheckbox, IOScheckbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Obtain a reference to the Full Name EditText
        final EditText fullNameEditText = (EditText) findViewById(R.id.full_name_editText);

        // Obtain a reference to the Password EditText
        final EditText passwordEditText = (EditText) findViewById(R.id.password_editText);

        // Date Picker for Birth Date
        dateOfBirthButton = (Button) findViewById(R.id.date_picker_button);
        dateOfBirthButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment fragment = new DatePickerFragment();
                fragment.show(getFragmentManager(), "datePicker");
            }
        });

        // Obtain a reference to the radio buttons to determine selected Gender
        genderRadioGroup = (RadioGroup) findViewById(R.id.gender_radio_group);

        // Spinner for grade classification
        final Spinner spinner = (Spinner) findViewById(R.id.classification_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.classification_array, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Checkboxes for Skills Selected
        androidCheckbox = (CheckBox) findViewById(R.id.skill_android);
        javaCheckbox = (CheckBox) findViewById(R.id.skill_java);
        cPlusCheckbox = (CheckBox) findViewById(R.id.skill_cPlus);
        swiftCheckbox = (CheckBox) findViewById(R.id.skill_swift);
        IOScheckbox = (CheckBox) findViewById(R.id.skill_IOS);

        Button registerButton = (Button) findViewById(R.id.register_btn);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fullName = fullNameEditText.getText().toString();
                password = passwordEditText.getText().toString();
                dateOfBirth = dateOfBirthButton.getText().toString();

                // Get the gender from the radioButton
                int selectedId = genderRadioGroup.getCheckedRadioButtonId();
                RadioButton selectedButton = (RadioButton) findViewById(selectedId);
                gender = selectedButton.getText().toString();

                String studentClassification = spinner.getSelectedItem().toString();

                if (androidCheckbox.isChecked()) {
                    skills.add("Android");
                }
                if (javaCheckbox.isChecked()) {
                    skills.add("Java");
                }
                if (cPlusCheckbox.isChecked()) {
                    skills.add("C++");
                }
                if (swiftCheckbox.isChecked()) {
                    skills.add("Swift");
                }
                if (IOScheckbox.isChecked()) {
                    skills.add("IOS");
                }


                Intent intent = new Intent(SignupActivity.this, RegisterActivity.class);
                intent.putExtra(RegisterActivity.FULL_NAME, fullName);
                intent.putExtra(RegisterActivity.PASSWORD, password);
                intent.putExtra(RegisterActivity.DATE_OF_BIRTH, dateOfBirth);
                intent.putExtra(RegisterActivity.GENDER, gender);
                intent.putExtra(RegisterActivity.CLASSIFICATION, studentClassification);
                intent.putExtra(RegisterActivity.SKILLS, skills);
                startActivity(intent);
            }
        });

    }
}

