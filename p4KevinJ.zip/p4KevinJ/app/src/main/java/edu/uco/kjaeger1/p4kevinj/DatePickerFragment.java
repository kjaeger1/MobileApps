package edu.uco.kjaeger1.p4kevinj;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;

/**
 * Created by kevinjaeger on 9/24/16.
 */

public class DatePickerFragment extends DialogFragment
        implements DatePickerDialog.OnDateSetListener {

    private int day = 1;
    private int month = 0;
    private int year = 2000;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(DatePicker view, int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day= day;
        ((Button)getActivity().findViewById(R.id.date_picker_button))
                .setText("" + getMonth() + "/" + getDay()+"/" + getYear());
    }

    public int getYear() {
        return year;
    }

    // Because January is shown as 0
    public int getMonth() {
        return month + 1;
    }

    public int getDay() {
        return day;
    }
}
