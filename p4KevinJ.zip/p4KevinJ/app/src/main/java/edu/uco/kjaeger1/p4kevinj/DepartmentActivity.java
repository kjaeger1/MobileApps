package edu.uco.kjaeger1.p4kevinj;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class DepartmentActivity extends Activity {

    private ActionMode actionMode;
    private ActionMode.Callback actionModeCallback;
    private ArrayList<Department> departments;
    private Department selectedDepartment;
    private boolean contextualMenuOpen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);
        actionModeCallback = new ActionModeCallback();
        departments = new ArrayList<>();

        CharSequence[] deptNames = getResources().getTextArray(R.array.dept_name_array);
        CharSequence[] deptNumbers = getResources().getTextArray(R.array.dept_phone_number_array);
        CharSequence[] deptURLs = getResources().getTextArray(R.array.dept_website_array);
        for (int i = 0; i < deptNames.length; i++) {
            departments.add(
                    new Department(
                            deptNames[i].toString(),
                            deptNumbers[i].toString(),
                            deptURLs[i].toString()));
        }

        ListView lv = (ListView) findViewById(R.id.dept_listView);

        ArrayAdapter<CharSequence> adapter = new ArrayAdapter<>(this, R.layout.department_list_item, deptNames);

        lv.setAdapter(adapter);
        lv.setLongClickable(true);

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (actionMode != null) {
                    return false;
                }
                selectedDepartment = departments.get(i);
                actionMode = DepartmentActivity.this.startActionMode(actionModeCallback);
                return true;
            }
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (!contextualMenuOpen) {
                    return;
                }
                selectedDepartment = departments.get(i);
            }
        });
    }

    private class ActionModeCallback implements ActionMode.Callback {

        // Called when the user selects a contextual menu item
        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case R.id.menu_phone:
                    Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + selectedDepartment.getPhoneNumber()));
                    startActivity(callIntent);
                    mode.finish(); // menu item chosen, closes contextual menu
                    return true;
                case R.id.menu_website:
                    Intent urlIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(selectedDepartment.getWebsite()));
                    startActivity(urlIntent);
                    mode.finish();
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.context_menu, menu);
            contextualMenuOpen = true;
            return true;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            actionMode = null;
            selectedDepartment = null;
            contextualMenuOpen = false;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }
    }
}
